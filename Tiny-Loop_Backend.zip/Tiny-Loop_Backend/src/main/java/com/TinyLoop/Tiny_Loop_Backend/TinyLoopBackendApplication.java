package com.TinyLoop.Tiny_Loop_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TinyLoopBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TinyLoopBackendApplication.class, args);
	}

}
