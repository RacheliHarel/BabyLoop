package com.TinyLoop.Tiny_Loop_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TinyLoopBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
